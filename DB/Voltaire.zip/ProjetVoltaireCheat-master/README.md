# ProjetVoltaireCheat

Extension prend la phrase du projet voltair, regarde dans reverso correcteur d’orthographe si elle est juste et affiche l'endroit de la faute si il y en a une.

# Build

Tu peux le build toi meme en faisant un yarn build à la racine.
Il faut nodejs et npm pour le build.
Sinon tu peux l'installer avec le build dejà fait avec le fichier extension.zip qui est au final juste le build zipper

# Download

<img width="921" alt="image" src="https://user-images.githubusercontent.com/35460122/221563442-c61bfe68-4e5d-43b2-9ead-f28cfe924b39.png">

<img width="767" alt="image" src="https://user-images.githubusercontent.com/35460122/221563745-91253f6e-657c-4d47-aeae-4d76143eee8e.png">

# Unzip

Unzip the file downloaded

<img width="762" alt="image" src="https://user-images.githubusercontent.com/35460122/221563910-af74ba80-99de-4d8c-b648-556d6250c152.png">

Unzip the "extension.zip" file

<img width="764" alt="image" src="https://user-images.githubusercontent.com/35460122/221564098-e238f0bc-5844-4881-8414-9d1c61b029e8.png">

# Install

En haut à droite d'un navigateur chromium (Chrome, Brave, ...)

![image](https://user-images.githubusercontent.com/35460122/221564521-6b7e702d-ccf1-4c38-91af-85ad6b82291c.png)

![image](https://user-images.githubusercontent.com/35460122/221564743-6bd6bdcb-3143-4e59-ace4-010079fc1aac.png)

# Activer le mode développeur et cliquer sur "Load Unpack" / "Chargé l'extension non empaqueté"

![image](https://user-images.githubusercontent.com/35460122/221565245-3ac9eebc-9392-44f0-9b50-576890d8cc47.png)

Trouvez le dossier "dist" qui était dans le fichier extension.zip

<img width="1119" alt="image" src="https://user-images.githubusercontent.com/35460122/221565571-b2e67dc4-0b53-49a8-9394-311d23ed5264.png">

Mettez l'extension en "PIN"

![image](https://user-images.githubusercontent.com/35460122/221565978-7e5e7ca2-8350-49a7-9457-aa6d55259b60.png)

## Utilisation.

Une fois que vous êtes en train de faire un test ou un exercice, cliquez sur l'icon de l’extention.
FYI: Il faut cliquer sur l'icon à chaque nouvelle phrase.
Si tous se passe bien, un carré de couleur s'affiche en bas a gauche de l'écran.
Vert: Reverso n'as pas detecté de problème avec la phrase. Ca ne veux pas dire qu'il n'y a pas de fautes.
Rouge: Le texte change de couleur à l'endroit de la faute.

<img width="2560" alt="image" src="https://github.com/MartinPELCAT/ProjetVoltaireCheat/assets/35460122/48335db2-d7c6-4ae4-873c-a69c2c071416">
<img width="2089" alt="image" src="https://github.com/MartinPELCAT/ProjetVoltaireCheat/assets/35460122/5ad6a7b3-2f19-4b97-b0f7-bc467fa5072a">

Normalement, si vous n'utiliez que l'extension vous avez plus de 50% de réussite !
