const { GatewayIntentBits, SlashCommandBuilder, MessageEmbed } = require("discord.js");
const Discord = require("discord.js");
const mineflayer = require('mineflayer');
const ownerID = "447672745287876622";
const Client = new Discord.Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildMessageTyping,
    ]
});
const date = new SlashCommandBuilder()
  .setName('date')
  .setDescription('Affiche la date actuelle');
let isBotActive = true;

//-------------------------------------------------------------------------------------------------
//pret
Client.on("ready", () => {
  Client.guilds.cache.get("1130792660546900061").commands.create(date);
  console.log("Cailloux's bot here");
}); 

 // Connexion au serveur Minecraft
 const bot = mineflayer.createBot({ host: 'mc.cailloux.xyz:25567', port: 25567, username: 'Cailloux777' });

 bot.once('spawn', () => {
   console.log('Minecraft bot is ready.');
 });

 bot.on('login', () => {
   const channel = Client.channels.cache.get('1130792660546900061');
   channel.send("Le serveur Minecraft est maintenant en ligne!");
 });

 bot.on('playerJoined', (player) => {
   const channel = Client.channels.cache.get('1130792660546900061');
   channel.send(`${player.username} a rejoint le serveur Minecraft.`);
 });

 bot.on('playerLeft', (player) => {
   const channel = Client.channels.cache.get('1130792660546900061');
   channel.send(`${player.username} a quitté le serveur Minecraft.`);
 });

 bot.on('end', () => {
   const channel = Client.channels.cache.get('1130792660546900061');
   channel.send("Le serveur Minecraft est maintenant hors ligne.");
 });

//---------------------------------------------------------------------------------------------
//Log
Client.on('message', message => {
  if (message.author.bot) return;

  console.log(`\n[MESSAGE] Content: ${message.content}`);
  console.log(`Channel ID: ${message.channelId}`);
  console.log(`Guild ID: ${message.guildId}`);



Client.on('messageUpdate', (oldMessage, newMessage) => {
  console.log(`\n[EDIT - ${oldMessage.guild.name}/${oldMessage.channel.name}] ${oldMessage.author.tag}: ${oldMessage.content} => ${newMessage.content}`);
});

Client.on('messageDelete', deletedMessage => {
  console.log(`\n[DELETE - ${deletedMessage.guild.name}/${deletedMessage.channel.name}] ${deletedMessage.author.tag}: ${deletedMessage.content}`);
});

});



//---------------------------------------------------------------------------------------------
//bienvenue
Client.on('guildMemberAdd', member => {
  const channelIDs = ['1130792660546900061', '851102761990094878', '957412580182339585', '1062412440945578018']; // Remplace par les IDs de tes salons
  const welcomeMessage = `Bienvenue sur le serveur, ${member}! Nous sommes ravis de t'accueillir ici.`;

  channelIDs.forEach(channelID => {
    const channel = member.guild.channels.cache.get(channelID);
    if (channel) {
      channel.send(welcomeMessage).catch(console.error);
    }
  });
});


// MESSAGE -------------------------------------------------------------------------------------------------
Client.on("messageCreate", message => {
  //----------------------------------------------------------------------------------------------
  //Supprimer
  if (message.content.startsWith("!supp")) {
    // Vérifier si l'auteur du message a les permissions nécessaires pour supprimer des messages
    if (!message.member.permissions.has("MANAGE_MESSAGES")) {
      return message.reply("Vous n'avez pas la permission d'utiliser cette commande.");
    }

    // Extraire la valeur spécifiée après "!supp"
    const value = message.content.slice("!supp".length).trim();

    // Vérifier si la valeur est un nombre valide
    if (isNaN(value) || value < 1 || value > 100) {
      return message.reply("Veuillez fournir un nombre entre 1 et 100.");
    }

    // Supprimer les messages dans le canal
    message.channel.bulkDelete(Number(value))
      .then(deletedMessages => {
        message.reply(`Suppression de ${deletedMessages.size} message(s).`);
      })
      .catch(error => {
        console.error(error);
        message.reply("Une erreur s'est produite lors de la suppression des messages.");
      });
  }

  //----------------------------------------------------------------------------------------------
  //bannir
  if (message.content.startsWith("!ban")) {
    // Vérifier si l'auteur du message a les permissions nécessaires pour bannir des membres
    if (!message.member.permissions.has("BAN_MEMBERS")) {
      return message.reply("Vous n'avez pas la permission d'utiliser cette commande.");
    }eee
    
    // Vérifier si l'utilisateur mentionné est présent et peut être banni
    const userToBan = message.mentions.users.first();
    if (!userToBan) {
      return message.reply("Veuillez mentionner l'utilisateur que vous souhaitez bannir.");
    }
    
    // Trouver le membre correspondant à l'utilisateur mentionné
    const memberToBan = message.guild.members.cache.get(userToBan.id);
    if (!memberToBan) {
      return message.reply("Cet utilisateur n'est pas présent sur le serveur.");
    }
    
    // Vérifier si le membre à bannir peut être banni (a un rôle inférieur ou égal au rôle de l'auteur du message)
    if (memberToBan.roles.highest.position >= message.member.roles.highest.position) {
      return message.reply("Vous ne pouvez pas bannir cet utilisateur car il a un rôle égal ou supérieur au vôtre.");
    }
    
    // Bannir le membre
    memberToBan.ban()
      .then(bannedMember => {
        message.reply(`L'utilisateur ${bannedMember.user.tag} a été banni avec succès.`);
      })
      .catch(error => {
        console.error(error);
        message.reply("Une erreur s'est produite lors de la tentative de bannissement de cet utilisateur.");
      });
  }
  
    

    //----------------------------------------------------------------------------------------------
    //sondage
    if (message.content.startsWith("!poll")) {
      const args = message.content.slice("!poll".length).trim().split('"');
      const question = args[1]?.trim();
      const options = [];
  
      for (let i = 2; i < args.length; i += 2) {
        options.push(args[i].trim());
      }
  
      if (!question || options.length < 2) {
        return message.reply("Utilisation correcte de la commande : `!poll \"Question\" \"Option 1\" \"Option 2\" ...`");
      }
  
      const pollEmbed = new MessageEmbed()
        .setColor("#7289DA")
        .setTitle("Sondage")
        .setDescription(question);
  
      for (let i = 0; i < options.length; i++) {
        const emoji = getEmojiFromIndex(i);
        const optionText = options[i];
  
        pollEmbed.addField(`${emoji} ${optionText}`, "0 votes", true);
      }
  
      message.channel.send({ embeds: [pollEmbed] })
        .then(pollMessage => {
          for (let i = 0; i < options.length; i++) {
            const emoji = getEmojiFromIndex(i);
            pollMessage.react(emoji);
          }
        })
        .catch(error => {
          console.error(error);
          message.reply("Une erreur s'est produite lors de la création du sondage.");
        });
    }
    
    //----------------------------------------------------------------------------------------------
    //décompte 
    if (message.content.startsWith("!count")) {
        const countValue = parseInt(message.content.split(" ")[1]);
    
        if (isNaN(countValue)) {
          message.reply("Veuillez fournir une valeur numérique valide après `!count`.");
          return;
        }
    
        if (countValue <= 0) {
          message.reply("Veuillez fournir une valeur supérieure à zéro.");
          return;
        }
    
        for (let i = countValue; i >= 0; i--) {
          setTimeout(() => {
            message.channel.send(i.toString());
          }, (countValue - i) * 1000);
        }
      }
      
    //----------------------------------------------------------------------------------------------
    //help
    if (message.content === "?help") {
        message.reply("Voici un résumé des commandes disponibles sur le bot Cailloux : \n \n \n !ban : Permet de bannir un membre du serveur. Seul un utilisateur ayant les permissions nécessaires peut utiliser cette commande. \n \n!poll : Permet de créer un sondage avec une question et plusieurs options. Les utilisateurs peuvent voter en réagissant avec des émojis. \n \n!count : Permet de démarrer un compte à rebours à partir d'un nombre spécifié. Le bot envoie des messages avec les chiffres décroissants jusqu'à zéro. \n \n?help : Affiche les différentes commandes du bot. \n \n!start et !pause : Permettent à l'administrateur du bot de le démarrer ou de le mettre en pause. Le bot ne répondra qu'aux commandes lorsque actif. \n \n!windows : Affiche des instructions sur la façon d'activer une clé de produit Windows. \n \n!rules : Affiche les règles du serveur. \n \n!gartic : Affiche une liste de noms et de descriptions associés à des utilisateurs du serveur. \n \n!annonce : Permet de faire une annonce en mentionnant 'everyone'. \n \n!insta, !ntr et !siteweb : Affichent des liens vers des profils Instagram et un site web.")}

    //----------------------------------------------------------------------------------------------
    //bot pause
    if (message.content === "!start") {
      if (message.author.id !== ownerID) {
        // Si l'auteur du message n'est pas l'administrateur, ne rien faire
        message.channel.send("Il n'y a que l'administrateur qui peut utiliser cette commande");
        return;
      }
      isBotActive = true;
      message.channel.send("Le bot est actif !");
    }
    
    if (message.content === "!pause") {
      if (message.author.id !== ownerID) {
        // Si l'auteur du message n'est pas l'administrateur, ne rien faire
        message.channel.send("Il n'y a que l'administrateur qui peut utiliser cette commande");
        return;
      }
      isBotActive = false;
      message.channel.send("Le bot est inactif !");
    }
    
    if (!isBotActive) {
      // Si le bot est inactif, ne rien faire
      return;
    }
    
    //----------------------------------------------------------------------------------------------
    //AMONG US 
    else if (message.content === "!tuto") {
      message.reply("Pour mobile (Android) :\n Téléchargez le jeu Among Us, créez votre compte, etc.\n Rendez-vous sur https://web.bettercrewl.ink/game depuis votre navigateur.\n Serveur vocal : Better-Crewlink \n normalement celui par défaut).\n Nom en jeu : 'votre nom d'utilisateur' (il est affiché dans le jeu sous 'Mon compte → Compte → NOM D'UTILISATEUR').\n Code du lobby : 'le code qui vous sera donné lors de la création de la partie'.\n Correction NAT : cochez cette option.\n Microphone : celui par défaut.\n Appuyez sur 'Connect'.\n Ensuite, entrez dans la partie sur Among Us.\n \n Pour PC (Steam et Epic Games) :\n Téléchargez BetterCrewLink depuis 'https://github.com/OhMyGuus/BetterCrewLink/releases/download/v3.1.3/Better-CrewLink-Setup-3.1.3.exe'. \n Installez-le. \n Exécutez-le.\n Ouvrez-le via soit Steam, soit Epic Games, selon celui que vous utilisez.\n Accédez aux paramètres.\n Configurez votre microphone et votre sortie audio sur 'Par défaut' (ou vos sorties spécifiques). \n Activez la détection vocale. \n Connectez-vous à la partie.");
   }
   else if (message.content === '!among') {
    message.reply("Préparez-vous pour une soirée palpitante sur Among Us le jeudi 8 décembre 2023 à 20h ! 🚀 \n\n🎮 Participants : <@447672745287876622> <@628645835126603776> <@629042626351464467> <@450554713746833409> <@641232970748919828> <@529458474401136657> <@434778400570474507> <@770378620995633163> <@780079564927533057> <@616406659186819088>  \n\n🕖 Pour profiter pleinement de l'expérience, nous vous recommandons vivement d'arriver entre 19h30 et 19h45 afin d'installer le chat de proximité et de configurer vos paramètres de micro. Cela nous permettra de débuter les parties sans encombre à 20h ! \n\nRejoignez-nous pour une soirée remplie de suspense, de trahisons et de fous rires. Préparez-vous à enquêter et à démasquer les imposteurs ! 🎉🔍✨");
  }
  
    //----------------------------------------------------------------------------------------------
    //autre 
    else if (message.content === "!windows") {
        message.reply("\n How to activate windows 10 key product key easly \n 1 - Select a windows key for which ever version of windows you are running.\n Home: TX9XD-98N7V-6WMQ6-BX7FG-H8Q99 \n Home N: 3KHY7-WNT83-DGQKR-F7HPR-844BM \n Home Single Language: 7HNRX-D7KGG-3K4RQ-4WPJ4-YTDFH \n Home Country Specific: PVMJN-6DFY6-9CCP6-7BKTT-D3WVR \n Professional N: MH37W-N47XK-V7XM9-C7227-GCQG9 \n Education: NW6C2-QMPVW-D7KKK-3GKT6-VCFB2 \n Education N: 2WH4N-8QGBV-H22JP-CT43Q-MDWWJ \n Enterprise: NPPR9-FWDCX-D2C8J-H872K-2YT43 \n Enterprise N: DPH2V-TTNVB-4X9Q3-TJR4H-KHJW4 \n 2 - Open Command Prompt as Administrator \n 3 - Run the command “slmgr /ipk YOURKEYHERE”  \n (use the key you selected from above, make sure its is for your correct version of windows).  \n Wait a few seconds and if done correctly you will get a white box that pops up saying Installed product key (YOURKEY) successfully \n 4 - Run the command “slmgr /skms kms8.msguides.com” Wait a few seconds and a white box should pop up saying  \n Key Management Service machine name set to kms8.msguides.com successfully \n 5 - Run the command “slmgr /ato” wait a few seconds and you should see a white box pop up confirming windows was activated. \n 6 - Done! Enjoy activated windows for FREE!!! \n");
    }
    else if (message.content === "!rules") {
        message.channel.send("**Règles du Serveur Discord** \n \n 1. Respectez les autres membres : Pas d'insultes, de harcèlement, de discours haineux ou de trolling envers les autres. Traitez tout le monde avec respect et amabilité. \n \n2. Pas de contenu inapproprié : Évitez de partager des images, des liens ou des discussions contenant du contenu à caractère sexuel, violent, ou toute autre chose qui pourrait être offensante. \n \n3. Pas de spam : Évitez de répéter plusieurs fois le même message, de publier des liens de manière excessive ou de spammer des émojis. \n \n4. Respectez les canaux thématiques : Utilisez les salons appropriés pour les discussions. Évitez les hors-sujets dans les canaux dédiés. \n \n5. Pas de publicité sans autorisation : N'envoyez pas de publicités pour d'autres serveurs Discord, des sites Web ou tout autre contenu sans autorisation. \n \n6. Pas de langage offensant : Évitez les jurons et le langage offensant. Gardez l'environnement convivial pour tous les âges. \n \n7. Pas d'usurpation d'identité : Ne vous faites pas passer pour quelqu'un d'autre, y compris pour les membres du personnel du serveur. \n \n8. Respectez les décisions du staff : Les modérateurs et administrateurs ont le dernier mot. Si vous avez des problèmes ou des questions, adressez-vous à eux en privé. \n \n9. Pas de contenu piraté : Ne partagez pas de logiciels, de films, de musique ou tout autre contenu protégé par des droits d'auteur sans autorisation. \n \n10. Restez en rapport avec le sujet du serveur : Ce serveur a été créé pour une communauté spécifique, veuillez donc garder les discussions en rapport avec le thème du serveur. \n \n11. Pas de demandes de rôles spéciaux : Les rôles spéciaux sont accordés à la discrétion du staff. N'en demandez pas de manière insistante. ");
    }
    else if (message.content === "!gartic") {
        message.reply("Cayol -> cheveux noirs bouclés \n Lety -> bleu \n Thibo -> cheveux marron bouclés, lunettes \n Beu -> cheveux marron lisses, lunettes \n Ghju -> casquette  \n Camille -> brune, 10cm de haut \n Axelle -> blonde, yeux bleus \n Arno -> gris lavabo \n Gui -> cheveux verts, sans bras \n Nico -> cheveux roses \n Lilas -> Cayol avec des cheveux longs \n Sam -> Rouge, cornes de diable \n Jalimo -> Jaune, coupe banane  \n Matisse -> Violet (en dessous du rouge) \n Yuckra -> Blond aux yeux bleus \n Louis -> Sa tête c’est une roue de vélo  \n Ana -> Un pancho jaune \n Candice -> Bleu avec des cheveux long \n");
    }
    
    if (message.content.startsWith("!annonce")) {
      const announcement = message.content.substring("!annonce".length).trim();
    
      if (!announcement) {
        message.reply("Veuillez fournir un message pour l'annonce.");
        return;
      }
    
      const formattedAnnouncement = `**ANNONCE :** ${announcement} \n||@everyone||`;
      message.channel.send(formattedAnnouncement)
        .then(() => {
          message.delete(); // Efface le message d'appel
        })
        .catch(error => {
          console.error('Erreur lors de la suppression du message :', error);
        });
    }
    

    //---------------------------------------------------------------------------------------------------
    //Réseaux
    else if (message.content === "!insta") {
      message.reply("https://www.instagram.com/matteo_cyl/");
    }
    else if (message.content === "!cailloux") {
      message.reply("https://cailloux.xyz/");
    }

    //-----------------------------------------------------------------------------------------
    //quoi feur
    if(message.content.toLowerCase().replace('?', '').replace(' ', '').endsWith('quoi')) message.reply('Feur !');
    if(message.content.toLowerCase().replace('?', '').replace(' ', '').endsWith('Jean')) message.reply('Cul !');
    if(message.content.toLowerCase().replace('?', '').replace(' ', '').endsWith('jean')) message.reply('Cul !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('oui')) message.reply('Stiti !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nez')) message.reply('Gros !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('né')) message.reply('Gros !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('née')) message.reply('Gros !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nées')) message.reply('Gros !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('ner')) message.reply('Gros !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('bambou')) message.reply('La !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('bamboue')) message.reply('La !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('bamboues')) message.reply('La !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('bambous')) message.reply('La !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('bambout')) message.reply('La !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('ni')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nis')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nie')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nies')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('ny')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('nit')) message.reply('Gger !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('mi')) message.reply('Grants !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('mis')) message.reply('Grants !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('mie')) message.reply('Grants !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('mies')) message.reply('Grants !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('my')) message.reply('Grants !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('hein')) message.reply('2 !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('cheh')) message.reply('vre !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('pk')) message.reply('jsp !');
    if(message.content.toLowerCase().replace(' ', '').replace('?', '').replace('.', '').replace('!', '').endsWith('tg')) message.reply('v !');
    

    
});
Client.login(""); 